#' Loan Dataset
#'
#' A synthetic dataset inspired by the Credit Risk dataset available on Kaggle.
#' It includes additional variables related to financial risk in loan approval.
#' The data were expanded using the SMOTENC algorithm to generate synthetic
#' observations and contain a mix of categorical and continuous features.
#' The version included in this package is a subset derived from the original source.
#'
#' @format A data frame with 10000 rows and 14 columns:
#' \describe{
#'   \item{person_age}{The person's age. (numeric)}
#'   \item{person_gender}{The person's gender. (character, "male" or "female")}
#'   \item{person_education}{The person's highest education level. (character, "High School", "Bachelor", "Master", "Doctorate", or "Associate")}
#'   \item{person_income}{The person's annual income. (numeric)}
#'   \item{person_emp_exp}{The person's ears of employment experience. (numeric)}
#'   \item{person_home_ownership}{The person's home ownership status. (character, "OTHER", "RENT", "MORTGAGE", or "OWN"))}
#'   \item{loan_amnt}{Loan amount requested. (numeric)}
#'   \item{loan_intent}{Purpose of the loan. (character)}
#'   \item{loan_int_rate}{Loan interest rate. (numeric)}
#'   \item{loan_percent_income}{The loan amount as a percentage of annual income. (numeric)}
#'   \item{cb_person_cred_hist_length}{The person's length of credit history in years. (numeric)}
#'   \item{credit_score}{The person's credit score. (numeric)}
#'   \item{previous_loan_defaults_on_file}{Indicator of whether the person has any prior loan defaults on record. (character, "No" or "Yes")}
#'   \item{loan_status}{Loan approval status. (numeric, 0 or 1)}
#' }
#'
#' @source https://www.kaggle.com/datasets/taweilo/loan-approval-classification-data
#'
"loan_dataset"
